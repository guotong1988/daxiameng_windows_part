/* iowin32.h -- IO base function header for compress/uncompress .zip
   Version 1.1, February 14h, 2010
   part of the MiniZip project

   Copyright (C) 1998-2010 Gilles Vollant
     http://www.winimage.com/zLibDll/minizip.html
   Modifications for Zip64 support
     Copyright (C) 2009-2010 Mathias Svensson
     http://result42.com

   This program is distributed under the terms of the same license as zlib.
   See the accompanying LICENSE file for the full text of the license.
*/

#ifndef _IOWIN32_H
#define _IOWIN32_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

void fill_win32_filefunc(zlib_filefunc_def *pzlib_filefunc_def);
void fill_win32_filefunc64(zlib_filefunc64_def *pzlib_filefunc_def);
void fill_win32_filefunc64A(zlib_filefunc64_def *pzlib_filefunc_def);
void fill_win32_filefunc64W(zlib_filefunc64_def *pzlib_filefunc_def);

#ifdef __cplusplus
}
#endif

#endif
